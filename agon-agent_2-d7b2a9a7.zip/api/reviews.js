import supabase from './_supabase.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { filter } = req.query;
      let query = supabase.from('reviews').select('*');
      if (filter === 'highest') {
        query = query.order('rating', { ascending: false }).order('date', { ascending: false });
      } else if (filter === 'recent') {
        query = query.order('date', { ascending: false });
      } else {
        query = query.order('rating', { ascending: false }).order('date', { ascending: false });
      }
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { reviewer_name, review_text, rating, profile_image } = req.body;
      const { data, error } = await supabase
        .from('reviews')
        .insert({ reviewer_name, review_text, rating, profile_image, date: new Date().toISOString() })
        .select()
        .single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({ error: err.message });
  }
}
