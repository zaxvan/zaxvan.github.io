import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

interface Review {
  id: number;
  reviewer_name: string;
  review_text: string;
  rating: number;
  date: string;
  profile_image: string;
}

const Reviews = () => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [filter, setFilter] = useState<'highest' | 'recent'>('highest');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const res = await fetch(`/api/reviews?filter=${filter}`);
        const data = await res.json();
        setReviews(data);
      } catch (err) {
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchReviews();
  }, [filter]);

  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) 
    : '4.8';

  return (
    <div className="bg-[#F8F5F0] pt-12 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">REAL STORIES FROM OUR GUESTS</div>
          <h1 className="text-6xl font-serif font-bold text-gray-900">Guest Reviews</h1>
        </div>

        {/* Rating Summary */}
        <div className="bg-white rounded-3xl p-10 mb-12 flex flex-col md:flex-row items-center justify-center gap-10 shadow">
          <div className="text-center">
            <div className="text-7xl font-serif font-bold text-[#8B0000]">{averageRating}</div>
            <div className="flex justify-center mt-2 mb-1">
              {[1,2,3,4,5].map(i => (
                <Star key={i} className="w-8 h-8 text-[#D4AF37]" />
              ))}
            </div>
            <div className="text-gray-600">Based on {reviews.length} reviews</div>
          </div>
          <div className="text-center md:text-left">
            <p className="text-xl text-gray-700 max-w-md">Our guests consistently rate us among the best Pakistani restaurants in Islamabad.</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-4 mb-8 justify-center">
          <button 
            onClick={() => setFilter('highest')}
            className={`px-6 py-2 rounded-full font-medium transition-colors ${filter === 'highest' ? 'bg-[#8B0000] text-white' : 'bg-white border hover:bg-gray-50'}`}
          >
            Highest Rated
          </button>
          <button 
            onClick={() => setFilter('recent')}
            className={`px-6 py-2 rounded-full font-medium transition-colors ${filter === 'recent' ? 'bg-[#8B0000] text-white' : 'bg-white border hover:bg-gray-50'}`}
          >
            Most Recent
          </button>
        </div>

        {loading ? (
          <div className="grid md:grid-cols-2 gap-6">
            {[1,2,3,4].map(i => (
              <div key={i} className="bg-white p-8 rounded-3xl animate-pulse">
                <div className="flex mb-4">
                  {[1,2,3,4,5].map(j => <div key={j} className="w-5 h-5 bg-gray-200 rounded mr-1" />)}
                </div>
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-3" />
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-8" />
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-200 rounded-full" />
                  <div>
                    <div className="h-4 bg-gray-200 rounded w-24 mb-1" />
                    <div className="h-3 bg-gray-200 rounded w-20" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {reviews.map((review, idx) => (
              <motion.div 
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-white p-8 rounded-3xl shadow-lg"
              >
                <div className="flex mb-4">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-[#D4AF37]" />
                  ))}
                </div>
                <p className="text-lg text-gray-700 italic mb-8">"{review.review_text}"</p>
                <div className="flex items-center gap-4">
                  <img 
                    src={review.profile_image || `https://ui-avatars.com/api/?name=${encodeURIComponent(review.reviewer_name)}&background=8B0000&color=fff`} 
                    alt={review.reviewer_name}
                    className="w-14 h-14 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-lg">{review.reviewer_name}</div>
                    <div className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <a 
            href="https://maps.google.com" 
            target="_blank"
            className="inline-block bg-[#D4AF37] text-[#8B0000] px-8 py-4 rounded-full font-semibold text-lg hover:bg-[#C5A22E] transition-colors"
          >
            Leave Your Review on Google
          </a>
        </div>
      </div>
    </div>
  );
};

export default Reviews;
