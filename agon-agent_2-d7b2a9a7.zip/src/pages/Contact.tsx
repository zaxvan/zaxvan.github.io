import { useState } from 'react';
import { Phone, MapPin, Clock, Mail } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', subject: '', message: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setSuccess(true);
        setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
        setTimeout(() => setSuccess(false), 3000);
      } else {
        alert('Failed to send message. Please try again.');
      }
    } catch (err) {
      alert('Error sending message. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <div className="pt-12 pb-20 bg-[#F8F5F0]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">GET IN TOUCH</div>
          <h1 className="text-6xl font-serif font-bold text-gray-900">Contact Us</h1>
          <p className="text-xl text-gray-600 mt-4 max-w-xl mx-auto">
            We'd love to hear from you. Reach out for reservations, inquiries, or just to say hello.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="bg-white p-10 rounded-3xl shadow-lg">
            <h2 className="text-3xl font-serif font-bold mb-8 text-gray-900">Visit Habibi Restaurant</h2>

            <div className="space-y-8">
              <div className="flex gap-5">
                <div className="text-[#D4AF37]"><MapPin className="w-8 h-8" /></div>
                <div>
                  <div className="font-semibold text-lg mb-1">Our Location</div>
                  <div className="text-gray-600">F-8 Markaz, Main Boulevard<br />Islamabad, Pakistan</div>
                  <a href="https://maps.google.com" target="_blank" className="text-[#8B0000] hover:underline text-sm">Get Directions →</a>
                </div>
              </div>

              <div className="flex gap-5">
                <div className="text-[#D4AF37]"><Phone className="w-8 h-8" /></div>
                <div>
                  <div className="font-semibold text-lg mb-1">Call Us</div>
                  <div>
                    <a href="tel:+92511112222" className="text-gray-800 hover:text-[#8B0000]">+92 51 111-222-22</a><br />
                    <a href="tel:+92515556666" className="text-gray-800 hover:text-[#8B0000]">+92 51 555-6666</a>
                  </div>
                </div>
              </div>

              <div className="flex gap-5">
                <div className="text-[#D4AF37]"><Mail className="w-8 h-8" /></div>
                <div>
                  <div className="font-semibold text-lg mb-1">Email Us</div>
                  <a href="mailto:info@habibirestaurant.pk" className="text-gray-800 hover:text-[#8B0000]">info@habibirestaurant.pk</a>
                </div>
              </div>

              <div className="flex gap-5">
                <div className="text-[#D4AF37]"><Clock className="w-8 h-8" /></div>
                <div>
                  <div className="font-semibold text-lg mb-1">Opening Hours</div>
                  <div className="text-gray-600">
                    Monday – Sunday<br />
                    12:00 PM – 11:00 PM
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-10 pt-8 border-t">
              <a 
                href="tel:+92511112222"
                className="flex items-center justify-center gap-3 bg-[#8B0000] text-white py-4 rounded-full text-lg font-semibold hover:bg-[#6B0000]"
              >
                <Phone className="w-5 h-5" /> Call Now for Reservations
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white p-10 rounded-3xl shadow-lg">
            <h2 className="text-3xl font-serif font-bold mb-8 text-gray-900">Send Us a Message</h2>
            
            {success && (
              <div className="bg-green-100 text-green-800 p-4 rounded-lg mb-6">
                Thank you! Your message has been sent successfully.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input 
                    type="text" 
                    name="name" 
                    value={formData.name} 
                    onChange={handleChange}
                    required 
                    className="w-full px-5 py-3 rounded-xl border border-gray-200 focus:border-[#D4AF37] focus:outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input 
                    type="email" 
                    name="email" 
                    value={formData.email} 
                    onChange={handleChange}
                    required 
                    className="w-full px-5 py-3 rounded-xl border border-gray-200 focus:border-[#D4AF37] focus:outline-none" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input 
                    type="tel" 
                    name="phone" 
                    value={formData.phone} 
                    onChange={handleChange}
                    className="w-full px-5 py-3 rounded-xl border border-gray-200 focus:border-[#D4AF37] focus:outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                  <select 
                    name="subject" 
                    value={formData.subject} 
                    onChange={handleChange}
                    required
                    className="w-full px-5 py-3 rounded-xl border border-gray-200 focus:border-[#D4AF37] focus:outline-none"
                  >
                    <option value="">Select subject</option>
                    <option value="Reservation">Reservation Inquiry</option>
                    <option value="Catering">Catering & Events</option>
                    <option value="Feedback">Feedback</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                <textarea 
                  name="message" 
                  value={formData.message} 
                  onChange={handleChange}
                  required 
                  rows={5}
                  className="w-full px-5 py-3 rounded-xl border border-gray-200 focus:border-[#D4AF37] focus:outline-none resize-y" 
                  placeholder="How can we help you?"
                />
              </div>

              <button 
                type="submit" 
                disabled={submitting}
                className="w-full bg-[#8B0000] text-white py-4 rounded-full font-semibold text-lg hover:bg-[#6B0000] disabled:opacity-50 transition-colors"
              >
                {submitting ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
