import { motion } from 'framer-motion';
import { Users, Award, Clock } from 'lucide-react';

const About = () => {
  return (
    <div className="bg-[#F8F5F0]">
      {/* Hero */}
      <div className="relative h-[70vh] flex items-center justify-center text-white overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/interior.jpg')" }}
        />
        <div className="absolute inset-0 bg-black/60" />
        
        <div className="relative z-10 text-center px-6">
          <div className="text-[#D4AF37] text-sm tracking-[4px] font-medium mb-4">EST. 1998</div>
          <h1 className="text-6xl md:text-7xl font-serif font-bold mb-6">Our Story</h1>
          <p className="text-2xl max-w-2xl mx-auto">A tradition of excellence in Pakistani cuisine for over two decades</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-20">
        <div className="prose prose-lg max-w-none">
          <p className="text-xl leading-relaxed text-gray-700">
            Habibi Restaurant Islamabad has earned its reputation as a trusted dining destination offering authentic Pakistani flavors and classic BBQ specialties. Located in the heart of the city, the restaurant blends traditional culinary heritage with modern hospitality.
          </p>
          <p className="text-xl leading-relaxed text-gray-700 mt-6">
            Known for its rich gravies, perfectly grilled meats, and aromatic rice dishes, Habibi continues to serve families, professionals, and visitors seeking quality food and welcoming ambiance. With a focus on freshness, generous portions, and consistent taste, Habibi Restaurant remains a place where guests return for comfort, celebration, and memorable meals.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
          {[
            { icon: <Clock className="w-12 h-12" />, number: "25", label: "Years of Excellence" },
            { icon: <Users className="w-12 h-12" />, number: "150K+", label: "Happy Guests" },
            { icon: <Award className="w-12 h-12" />, number: "50+", label: "Signature Dishes" },
          ].map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="text-center bg-white p-8 rounded-3xl shadow"
            >
              <div className="text-[#D4AF37] mb-4 flex justify-center">{stat.icon}</div>
              <div className="text-5xl font-serif font-bold text-[#8B0000] mb-2">{stat.number}</div>
              <div className="font-medium text-gray-600">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Meet the Team */}
      <div className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">THE CULINARY TEAM</div>
            <h2 className="text-5xl font-serif font-bold">Meet Our Chefs</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Chef Ahmed Khan", role: "Executive Chef", desc: "With 25 years experience in Pakistani cuisine, Chef Ahmed is the heart of our kitchen." },
              { name: "Chef Fatima Rizvi", role: "Head of BBQ", desc: "Specializing in traditional tandoor and charcoal grilling techniques." },
              { name: "Chef Bilal Ahmed", role: "Sous Chef", desc: "Expert in Mughlai and regional Pakistani specialties." },
            ].map((chef, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                className="bg-[#F8F5F0] p-8 rounded-3xl text-center"
              >
                <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-[#8B0000] flex items-center justify-center text-white text-4xl font-serif">
                  {chef.name.split(' ').map(n => n[0]).join('')}
                </div>
                <h3 className="text-2xl font-serif font-bold mb-1">{chef.name}</h3>
                <div className="text-[#D4AF37] font-medium mb-4">{chef.role}</div>
                <p className="text-gray-600">{chef.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Branches */}
      <div className="py-20 bg-[#F8F5F0]">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">OUR LOCATIONS</div>
          <h2 className="text-5xl font-serif font-bold mb-12">Visit Us at F-8 Markaz</h2>
          
          <div className="bg-white p-12 rounded-3xl shadow-xl">
            <div className="text-3xl font-serif font-bold text-[#8B0000] mb-4">Habibi Restaurant</div>
            <div className="text-xl text-gray-700 mb-6">F-8 Markaz, Main Boulevard, Islamabad</div>
            
            <div className="flex flex-col md:flex-row gap-8 justify-center items-center">
              <div>
                <div className="font-semibold">Phone</div>
                <a href="tel:+92511112222" className="text-[#8B0000]">+92 51 111-222-22</a>
              </div>
              <div>
                <div className="font-semibold">Hours</div>
                <div>12:00 PM – 11:00 PM Daily</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
