import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, Minus } from 'lucide-react';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url: string;
  ingredients: string;
  spice_level: number;
}

interface CartItem extends MenuItem {
  quantity: number;
}

const CATEGORIES = [
  'all', 'Starters', 'Soups', 'BBQ', 'Karahi and Handi', 'Mughlai Dishes',
  'Rice and Biryani', 'Chinese', 'Salads', 'Tandoor and Breads', 'Beverages'
];

const Menu = () => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchMenu = async () => {
      try {
        const res = await fetch('/api/menu');
        const data = await res.json();
        setMenuItems(data);
      } catch (err) {
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchMenu();

    // Load cart from localStorage
    const savedCart = localStorage.getItem('habibiCart');
    if (savedCart) setCart(JSON.parse(savedCart));
  }, []);

  useEffect(() => {
    localStorage.setItem('habibiCart', JSON.stringify(cart));
  }, [cart]);

  const filteredItems = menuItems
    .filter(item => selectedCategory === 'all' || item.category === selectedCategory)
    .filter(item => 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const addToCart = (item: MenuItem, qty: number = 1) => {
    setCart(prev => {
      const existing = prev.findIndex(cartItem => cartItem.id === item.id);
      if (existing !== -1) {
        return prev.map((cartItem, idx) => 
          idx === existing ? { ...cartItem, quantity: cartItem.quantity + qty } : cartItem
        );
      }
      return [...prev, { ...item, quantity: qty }];
    });
    setShowCart(true);
  };

  const updateQuantity = (id: number, newQty: number) => {
    if (newQty < 1) return;
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: newQty } : item
    ));
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const getSpiceLevel = (level: number) => {
    return '🌶️'.repeat(Math.max(1, level || 1));
  };

  return (
    <div className="pt-8 pb-20 bg-[#F8F5F0]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">DISCOVER OUR FLAVORS</div>
          <h1 className="text-6xl font-serif font-bold text-gray-900">Our Menu</h1>
          <p className="text-xl text-gray-600 mt-4 max-w-xl mx-auto">
            Authentic Pakistani &amp; BBQ specialties, prepared with passion and tradition
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <input
            type="text"
            placeholder="Search dishes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 px-5 py-3 rounded-full border border-gray-200 focus:outline-none focus:border-[#D4AF37] text-lg"
          />
          <div className="flex gap-2 overflow-x-auto pb-2">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2 rounded-full whitespace-nowrap transition-colors text-sm font-medium ${selectedCategory === cat ? 'bg-[#8B0000] text-white' : 'bg-white hover:bg-gray-100 border'}`}
              >
                {cat === 'all' ? 'All' : cat}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3,4,5,6].map(i => (
              <div key={i} className="bg-white rounded-3xl overflow-hidden shadow animate-pulse">
                <div className="h-56 bg-gray-200" />
                <div className="p-6">
                  <div className="h-6 bg-gray-200 rounded mb-3" />
                  <div className="h-4 bg-gray-200 rounded w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item, idx) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.02 }}
                className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-all group cursor-pointer"
                onClick={() => setSelectedDish(item)}
              >
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={item.image_url || '/images/kabuli-pulao.jpg'} 
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-white/95 px-3 py-1 rounded-full font-semibold text-[#8B0000]">
                    Rs. {item.price}
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-2xl font-serif font-bold text-gray-900">{item.name}</h3>
                    <div className="text-xl">{getSpiceLevel(item.spice_level)}</div>
                  </div>
                  <p className="text-gray-600 line-clamp-2 mb-4">{item.description}</p>
                  <div className="flex items-center justify-between">
                    <button 
                      onClick={(e) => { e.stopPropagation(); addToCart(item); }}
                      className="flex items-center gap-2 bg-[#8B0000] text-white px-5 py-2.5 rounded-full hover:bg-[#6B0000] transition-colors"
                    >
                      <Plus className="w-4 h-4" /> Add to Cart
                    </button>
                    <span className="text-sm text-gray-500">{item.category}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {filteredItems.length === 0 && !loading && (
          <div className="text-center py-20">
            <p className="text-2xl text-gray-500">No dishes found matching your search.</p>
          </div>
        )}
      </div>

      {/* Dish Detail Modal */}
      <AnimatePresence>
        {selectedDish && (
          <div className="fixed inset-0 bg-black/70 z-[100] flex items-center justify-center p-4" onClick={() => setSelectedDish(null)}>
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative h-80">
                <img 
                  src={selectedDish.image_url || '/images/kabuli-pulao.jpg'} 
                  alt={selectedDish.name}
                  className="w-full h-full object-cover"
                />
                <button 
                  onClick={() => setSelectedDish(null)}
                  className="absolute top-4 right-4 bg-white/90 p-3 rounded-full hover:bg-white"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="absolute bottom-4 right-4 bg-white px-5 py-2 rounded-full font-bold text-[#8B0000] text-xl">
                  Rs. {selectedDish.price}
                </div>
              </div>
              <div className="p-8">
                <div className="flex justify-between items-start mb-4">
                  <h2 className="text-4xl font-serif font-bold text-gray-900">{selectedDish.name}</h2>
                  <div className="text-3xl">{getSpiceLevel(selectedDish.spice_level)}</div>
                </div>
                <p className="text-xl text-gray-700 mb-6">{selectedDish.description}</p>
                
                {selectedDish.ingredients && (
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Ingredients</h4>
                    <p className="text-gray-600">{selectedDish.ingredients}</p>
                  </div>
                )}

                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-10 h-10 flex items-center justify-center border rounded-full hover:bg-gray-100"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="text-2xl font-medium w-8 text-center">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-10 h-10 flex items-center justify-center border rounded-full hover:bg-gray-100"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  <button 
                    onClick={() => {
                      addToCart(selectedDish, quantity);
                      setSelectedDish(null);
                      setQuantity(1);
                    }}
                    className="flex-1 bg-[#8B0000] text-white py-4 rounded-full text-lg font-semibold hover:bg-[#6B0000]"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {showCart && cart.length > 0 && (
          <div className="fixed inset-0 bg-black/70 z-[200]" onClick={() => setShowCart(false)}>
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl flex flex-col"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-6 border-b flex justify-between items-center">
                <h3 className="text-2xl font-serif font-bold">Your Order</h3>
                <button onClick={() => setShowCart(false)}><X /></button>
              </div>

              <div className="flex-1 overflow-auto p-6 space-y-4">
                {cart.map(item => (
                  <div key={item.id} className="flex gap-4 bg-gray-50 p-4 rounded-xl">
                    <img 
                      src={item.image_url || '/images/kabuli-pulao.jpg'} 
                      alt={item.name}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="font-semibold">{item.name}</div>
                      <div className="text-sm text-gray-500">Rs. {item.price} × {item.quantity}</div>
                      <div className="flex items-center gap-2 mt-2">
                        <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-7 h-7 flex items-center justify-center border rounded-full">-</button>
                        <span>{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-7 h-7 flex items-center justify-center border rounded-full">+</button>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">Rs. {item.price * item.quantity}</div>
                      <button 
                        onClick={() => removeFromCart(item.id)} 
                        className="text-red-500 text-sm mt-2 hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-6 border-t bg-gray-50">
                <div className="flex justify-between text-xl font-bold mb-4">
                  <span>Total</span>
                  <span>Rs. {totalPrice}</span>
                </div>
                <button 
                  onClick={() => {
                    alert(`Thank you for your order! Total: Rs. ${totalPrice}. Please call us at +92 51 111-222-22 to confirm.`);
                    setCart([]);
                    setShowCart(false);
                  }}
                  className="w-full bg-[#8B0000] text-white py-4 rounded-full font-semibold text-lg hover:bg-[#6B0000]"
                >
                  Place Order
                </button>
                <p className="text-center text-sm text-gray-500 mt-3">Or call +92 51 111-222-22 for pickup/delivery</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cart Button */}
      {cart.length > 0 && (
        <button 
          onClick={() => setShowCart(true)}
          className="fixed bottom-6 right-6 bg-[#8B0000] text-white px-6 py-4 rounded-full shadow-xl flex items-center gap-3 z-[90]"
        >
          <div className="relative">
            🛒
            <span className="absolute -top-2 -right-2 bg-[#D4AF37] text-[#8B0000] text-xs w-5 h-5 flex items-center justify-center rounded-full">
              {cart.length}
            </span>
          </div>
          <span className="font-semibold">View Cart (Rs. {totalPrice})</span>
        </button>
      )}
    </div>
  );
};

export default Menu;
