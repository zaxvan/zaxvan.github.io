import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Clock, MapPin, Phone } from 'lucide-react';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url: string;
  spice_level: number;
}

interface Review {
  id: number;
  reviewer_name: string;
  review_text: string;
  rating: number;
  date: string;
  profile_image: string;
}

const Home = () => {
  const [featuredDishes, setFeaturedDishes] = useState<MenuItem[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [menuRes, reviewsRes] = await Promise.all([
          fetch('/api/menu'),
          fetch('/api/reviews?filter=highest'),
        ]);
        const menuData = await menuRes.json();
        const reviewsData = await reviewsRes.json();
        setFeaturedDishes(menuData.slice(0, 6));
        setReviews(reviewsData.slice(0, 3));
      } catch (err) {
        console.error('Fetch error:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const scrollToMenu = () => {
    window.scrollTo({ top: 800, behavior: 'smooth' });
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-[100dvh] flex items-center justify-center text-white">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/hero.jpg')" }}
        />
        <div className="absolute inset-0 bg-black/60" />
        
        <div className="relative z-10 text-center px-6 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-4 py-1 bg-[#D4AF37] text-[#8B0000] rounded-full text-sm font-medium mb-6 tracking-widest">
              ESTABLISHED 1998
            </div>
            <h1 className="text-6xl md:text-8xl font-serif font-bold mb-4 tracking-tight">HABIBI</h1>
            <p className="text-2xl md:text-3xl font-serif text-[#D4AF37] mb-4">Restaurant Islamabad</p>
            <p className="text-xl md:text-2xl text-gray-200 max-w-2xl mx-auto mb-10">
              Authentic Pakistani &amp; BBQ Cuisine
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={scrollToMenu}
                className="bg-[#D4AF37] text-[#8B0000] px-10 py-4 rounded-full font-semibold text-lg hover:bg-white transition-colors flex items-center justify-center gap-2"
              >
                View Our Menu
              </button>
              <Link 
                to="/contact"
                className="border-2 border-white text-white px-10 py-4 rounded-full font-semibold text-lg hover:bg-white hover:text-[#8B0000] transition-colors flex items-center justify-center"
              >
                Reserve a Table
              </Link>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="text-white/70 text-sm">Scroll to explore</div>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">WELCOME TO HABIBI</div>
          <h2 className="text-5xl font-serif font-bold text-gray-900 mb-8 leading-tight">
            Where Tradition Meets Excellence
          </h2>
          <p className="text-xl text-gray-600 leading-relaxed max-w-2xl mx-auto">
            For over two decades, Habibi Restaurant has been Islamabad's premier destination for authentic Pakistani and BBQ cuisine. 
            Our family recipes, fresh ingredients, and generous portions have made us a beloved gathering place for families and friends.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            {[
              { icon: <Clock className="w-10 h-10" />, title: "Open Daily", desc: "12 PM - 11 PM" },
              { icon: <MapPin className="w-10 h-10" />, title: "Prime Location", desc: "F-8 Markaz" },
              { icon: <Phone className="w-10 h-10" />, title: "Reservations", desc: "Call Us Today" },
            ].map((item, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="text-center"
              >
                <div className="text-[#D4AF37] mb-4 flex justify-center">{item.icon}</div>
                <h3 className="font-semibold text-xl mb-2 text-gray-900">{item.title}</h3>
                <p className="text-gray-600">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="py-20 bg-[#F8F5F0]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">SIGNATURE DISHES</div>
            <h2 className="text-5xl font-serif font-bold text-gray-900">Our Specialties</h2>
            <p className="mt-4 text-gray-600 max-w-xl mx-auto">Handcrafted with love using authentic recipes and the finest ingredients</p>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1,2,3,4,5,6].map(i => (
                <div key={i} className="bg-white rounded-3xl overflow-hidden shadow animate-pulse">
                  <div className="h-64 bg-gray-200" />
                  <div className="p-6">
                    <div className="h-6 bg-gray-200 rounded mb-3" />
                    <div className="h-4 bg-gray-200 rounded w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredDishes.map((dish, idx) => (
                <motion.div 
                  key={dish.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all group"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={dish.image_url || '/images/kabuli-pulao.jpg'} 
                      alt={dish.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full font-semibold text-[#8B0000] text-sm">
                      Rs. {dish.price}
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-2xl font-serif font-bold mb-2 text-gray-900">{dish.name}</h3>
                    <p className="text-gray-600 line-clamp-2 mb-4">{dish.description}</p>
                    <Link 
                      to="/menu" 
                      className="inline-flex items-center text-[#8B0000] font-medium hover:text-[#D4AF37] transition-colors"
                    >
                      View Details →
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link 
              to="/menu" 
              className="inline-block bg-[#8B0000] text-white px-10 py-4 rounded-full font-semibold text-lg hover:bg-[#6B0000] transition-colors"
            >
              Explore Full Menu
            </Link>
          </div>
        </div>
      </section>

      {/* Location & Hours */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">FIND US IN THE HEART OF ISLAMABAD</div>
              <h2 className="text-5xl font-serif font-bold mb-8 leading-tight">A Destination for Memorable Meals</h2>
              
              <div className="space-y-6 text-lg text-gray-700">
                <div className="flex gap-4">
                  <MapPin className="w-6 h-6 text-[#D4AF37] mt-1 flex-shrink-0" />
                  <div>
                    <strong>F-8 Markaz, Islamabad</strong><br />
                    Near F-8 Markaz, Main Boulevard
                  </div>
                </div>
                <div className="flex gap-4">
                  <Clock className="w-6 h-6 text-[#D4AF37] mt-1 flex-shrink-0" />
                  <div>
                    <strong>Open Daily:</strong> 12:00 PM – 11:00 PM<br />
                    We are open every day of the year
                  </div>
                </div>
                <div className="flex gap-4">
                  <Phone className="w-6 h-6 text-[#D4AF37] mt-1 flex-shrink-0" />
                  <div>
                    <strong>Reservations:</strong><br />
                    <a href="tel:+92511112222" className="text-[#8B0000]">+92 51 111-222-22</a>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <a 
                  href="https://maps.google.com" 
                  target="_blank"
                  className="inline-block bg-[#D4AF37] text-[#8B0000] px-8 py-3 rounded-full font-semibold hover:bg-[#C5A22E] transition-colors"
                >
                  Get Directions on Google Maps
                </a>
              </div>
            </div>

            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3620.404!2d73.040!3d33.720!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzPCsDQzJzEyLjAiTiA3M8KwMDInMjQuMCJF!5e0!3m2!1sen!2spk!4v1620000000000" 
                className="w-full h-[500px] border-0"
                allowFullScreen 
              />
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Preview */}
      <section className="py-20 bg-[#F8F5F0]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">GUEST EXPERIENCES</div>
            <h2 className="text-5xl font-serif font-bold text-gray-900">What Our Guests Say</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {reviews.map((review, idx) => (
              <motion.div 
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white p-8 rounded-3xl shadow-lg"
              >
                <div className="flex mb-4">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-[#D4AF37]" />
                  ))}
                </div>
                <p className="text-gray-700 text-lg italic mb-6">"{review.review_text}"</p>
                <div className="flex items-center gap-4">
                  <img 
                    src={review.profile_image || `https://ui-avatars.com/api/?name=${encodeURIComponent(review.reviewer_name)}&background=8B0000&color=fff`} 
                    alt={review.reviewer_name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold">{review.reviewer_name}</div>
                    <div className="text-sm text-gray-500">{new Date(review.date).toLocaleDateString()}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link 
              to="/reviews" 
              className="inline-block border-2 border-[#8B0000] text-[#8B0000] px-8 py-3 rounded-full font-semibold hover:bg-[#8B0000] hover:text-white transition-colors"
            >
              Read All Reviews
            </Link>
          </div>
        </div>
      </section>

      {/* Gallery Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-[#8B0000] text-sm tracking-[3px] font-medium mb-4">CAPTURED MOMENTS</div>
            <h2 className="text-5xl font-serif font-bold text-gray-900">The Habibi Experience</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1,2,3,4,5,6].map((i) => (
              <div key={i} className="relative aspect-[4/3] overflow-hidden rounded-2xl">
                <img 
                  src={i % 2 === 0 ? '/images/interior.jpg' : '/images/hero.jpg'} 
                  alt="Restaurant ambiance" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link 
              to="/menu" 
              className="inline-block bg-[#8B0000] text-white px-10 py-4 rounded-full font-semibold text-lg hover:bg-[#6B0000] transition-colors"
            >
              Visit Us Today
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
