import { Link } from 'react-router-dom';
import { Phone, MapPin, Clock, Mail } from 'lucide-react';

const Footer = () => {
  const handleSubscribe = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const email = (form.elements.namedItem('email') as HTMLInputElement).value;

    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      if (res.ok) {
        alert('Thank you for subscribing to our newsletter!');
        form.reset();
      }
    } catch (err) {
      alert('Subscription failed. Please try again.');
    }
  };

  return (
    <footer className="bg-[#2C1810] text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-14 h-14 bg-[#D4AF37] rounded-full flex items-center justify-center">
                <span className="text-[#8B0000] text-3xl font-serif">H</span>
              </div>
              <div>
                <h2 className="text-3xl font-serif font-bold tracking-wide">HABIBI</h2>
                <p className="text-xs text-[#D4AF37]">RESTAURANT ISLAMABAD</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Experience authentic Pakistani and BBQ cuisine in the heart of Islamabad. 
              Where tradition meets excellence.
            </p>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-semibold mb-6 text-[#D4AF37]">Visit Us</h3>
            <div className="space-y-4 text-sm">
              <div className="flex gap-3">
                <MapPin className="w-5 h-5 text-[#D4AF37] mt-1 flex-shrink-0" />
                <div>
                  <p>F-8 Markaz, Islamabad</p>
                  <p className="text-gray-400">Pakistan</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Phone className="w-5 h-5 text-[#D4AF37] mt-1 flex-shrink-0" />
                <div>
                  <a href="tel:+92511112222" className="hover:text-[#D4AF37]">+92 51 111-222-22</a>
                  <br />
                  <a href="tel:+92515556666" className="hover:text-[#D4AF37]">+92 51 555-6666</a>
                </div>
              </div>
              <div className="flex gap-3">
                <Mail className="w-5 h-5 text-[#D4AF37] mt-1 flex-shrink-0" />
                <a href="mailto:info@habibirestaurant.pk" className="hover:text-[#D4AF37]">info@habibirestaurant.pk</a>
              </div>
              <div className="flex gap-3">
                <Clock className="w-5 h-5 text-[#D4AF37] mt-1 flex-shrink-0" />
                <div>
                  <p>Daily: 12:00 PM - 11:00 PM</p>
                  <p className="text-gray-400">Open all days</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-6 text-[#D4AF37]">Quick Links</h3>
            <div className="space-y-3 text-sm">
              <Link to="/" className="block hover:text-[#D4AF37]">Home</Link>
              <Link to="/menu" className="block hover:text-[#D4AF37]">Our Menu</Link>
              <Link to="/about" className="block hover:text-[#D4AF37]">About Us</Link>
              <Link to="/reviews" className="block hover:text-[#D4AF37]">Guest Reviews</Link>
              <Link to="/contact" className="block hover:text-[#D4AF37]">Contact Us</Link>
              <a href="https://maps.google.com" target="_blank" className="block hover:text-[#D4AF37]">Get Directions</a>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-xl font-semibold mb-6 text-[#D4AF37]">Stay Updated</h3>
            <p className="text-gray-400 text-sm mb-4">
              Subscribe to receive special offers and updates from Habibi Restaurant.
            </p>
            <form onSubmit={handleSubscribe} className="flex flex-col gap-3">
              <input
                type="email"
                name="email"
                placeholder="Your email address"
                required
                className="bg-white/10 border border-white/20 px-4 py-3 rounded-lg text-sm placeholder:text-gray-500 focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                type="submit"
                className="bg-[#D4AF37] text-[#8B0000] py-3 rounded-lg font-semibold hover:bg-[#C5A22E] transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} Habibi Restaurant Islamabad. All Rights Reserved.</p>
          <p className="mt-1">Crafted with love for authentic Pakistani cuisine.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
