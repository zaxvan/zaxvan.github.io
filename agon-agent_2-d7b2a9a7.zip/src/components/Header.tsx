import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { path: '/', label: 'Home' },
    { path: '/menu', label: 'Menu' },
    { path: '/about', label: 'About Us' },
    { path: '/reviews', label: 'Reviews' },
    { path: '/contact', label: 'Contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="bg-[#8B0000] text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#D4AF37] rounded-full flex items-center justify-center">
              <span className="text-[#8B0000] text-2xl font-serif">H</span>
            </div>
            <div>
              <h1 className="text-2xl font-serif font-bold tracking-wide">HABIBI</h1>
              <p className="text-xs text-[#D4AF37] -mt-1">RESTAURANT ISLAMABAD</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`font-medium transition-colors hover:text-[#D4AF37] ${isActive(link.path) ? 'text-[#D4AF37]' : ''}`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <a href="tel:+92511112222" className="flex items-center gap-2 bg-[#D4AF37] text-[#8B0000] px-4 py-2 rounded-full hover:bg-white transition-colors">
              <Phone className="w-4 h-4" />
              <span className="font-medium">+92 51 111-222-22</span>
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-white"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 border-t border-white/20">
            <nav className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`font-medium py-2 px-4 transition-colors hover:bg-white/10 rounded ${isActive(link.path) ? 'text-[#D4AF37]' : ''}`}
                >
                  {link.label}
                </Link>
              ))}
              <a href="tel:+92511112222" className="flex items-center gap-2 bg-[#D4AF37] text-[#8B0000] px-4 py-3 rounded-full mx-4 mt-2">
                <Phone className="w-4 h-4" />
                <span className="font-medium">+92 51 111-222-22</span>
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
